const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'soundwave_api', 
    password: '1234', // <--- Pon tu clave aquí
    port: 5432,
});

// Endpoint para obtener el catálogo de canciones
app.get('/api/catalogo', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM obtener_catalogo_completo()'); 
        res.json(result.rows); 
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

app.listen(3000, () => console.log('Backend corriendo en http://localhost:3000'));